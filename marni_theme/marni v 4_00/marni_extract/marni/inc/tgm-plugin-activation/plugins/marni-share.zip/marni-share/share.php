<?php
/*
Plugin Name: Marni Share Buttons
Plugin URI: http://www.red-sun-design.com
Description: Share Buttons for Marni WordPress Theme
Version: 2.0
Author: Gerda Gimpl
Author URI: http://www.red-sun-design.com
*/



if ( ! function_exists( 'marni_share_buttons' ) ) {
  	function marni_share_buttons() { ?>
		<div class="post-share">
			<div class="share-text"><?php esc_html_e('Share','marni'); ?></div>
			<?php if (get_theme_mod('marni_facebook',true) == true) { ?>
				<a target="_blank" rel="nofollow" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>"><i class="fa fa-facebook"></i></a>
			<?php } ?>

			<?php if (get_theme_mod('marni_twitter',true) == true) { ?>
	        		<a target="_blank" rel="nofollow" href="https://twitter.com/share?url=<?php the_permalink(); ?>"><i class="fa-brands fa-x-twitter"></i></a>
			<?php } ?>

			<?php if (get_theme_mod('marni_pinterest',true) == true) { ?>
	        		<a target="_blank" rel="nofollow" href="https://pinterest.com/pin/create/bookmarklet/?media=<?php the_post_thumbnail_url(); ?>&amp;url=<?php the_permalink(); ?>&amp;description=<?php echo urlencode(get_the_title()); ?>"><i class="fa fa-pinterest"></i></a>
			<?php } ?>

			<?php if (get_theme_mod('marni_email',true) == true) { ?>
				<a href="mailto:?subject=<?php echo urlencode(get_the_permalink()); ?>&amp;body=<?php the_permalink() ?>"><i class="fa fa-envelope"></i></a>
			<?php } ?>
		</div>
  	<?php }
}


?>
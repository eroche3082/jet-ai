<?php
/*
Plugin Name: Marni Custom Post Types
Plugin URI: http://www.red-sun-design.com
Description: Custom Post Types and Taxonomies for Marni WordPress Theme
Version: 1.0
Author: Gerda Gimpl
Author URI: http://www.red-sun-design.com
*/



/** INCLUDE CUSTOM POST TYPES *************************************************/
include_once plugin_dir_path( __FILE__ ) . 'posttypes/content-boxes.php';

?>
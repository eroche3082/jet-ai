<?php

// REGISTER CONTENT BOXES POST TYPE

add_action('init', 'marni_register_posttype_contentboxes');
function marni_register_posttype_contentboxes() {
        $labels = array(
                'name' => esc_html__('Featured Boxes', 'marni'),
                'singular_name' => esc_html__('Featured Box', 'marni'),
		'menu_name' => esc_html__('Featured Boxes', 'marni'),
		'name_admin_bar' => esc_html__('All Featured Boxes', 'marni'),
		'all_items' => esc_html__('All Featured Boxes', 'marni'),
                'add_new' => esc_html__('Add New Featured Box', 'marni'),
                'add_new_item' => esc_html__('Add New Featured Box', 'marni'),
                'edit_item' => esc_html__('Edit Featured Box', 'marni'),
                'new_item' => esc_html__('New Featured Box', 'marni'),
                'view_item' => esc_html__('View Featured Box', 'marni'),
                'search_items' => esc_html__('Search Featured Boxes', 'marni'),
                'not_found' =>  esc_html__('No Featured Boxes were found with that criteria', 'marni'),
                'not_found_in_trash' => esc_html__('No Featured Boxes were found in the Trash with that criteria', 'marni'),
                'view' =>  esc_html__('View Featured Box', 'marni')
        );

        $args = array(
                'labels' => $labels,
                'description' => esc_html__('This is the holding location for all Featured Boxes', 'marni'),
                'public' => true,
                'publicly_queryable' => true,
                'exclude_from_search' => false,
                'show_ui' => true,
                'rewrite' => true,
                'hierarchical' => true,
                'menu_position' => 5,
                'menu_icon' => 'dashicons-screenoptions',
                'supports' => array('thumbnail','title')
        );

	register_post_type('contentboxes',$args);
}
?>
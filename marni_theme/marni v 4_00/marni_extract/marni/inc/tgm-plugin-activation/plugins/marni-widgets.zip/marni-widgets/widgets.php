<?php
/*
Plugin Name: Marni Widgets
Plugin URI: http://www.red-sun-design.com
Description: Widgets for Marni WordPress Theme
Version: 1.1
Author: Gerda Gimpl
Author URI: http://www.red-sun-design.com
*/



/** INCLUDE CUSTOM POST TYPES *************************************************/
include_once plugin_dir_path( __FILE__ ) . 'widgets/widget-social.php';
include_once plugin_dir_path( __FILE__ ) . 'widgets/widget-categories.php';
include_once plugin_dir_path( __FILE__ ) . 'widgets/widget-featured-post.php';
include_once plugin_dir_path( __FILE__ ) . 'widgets/widget-popular-posts.php';



/* enable shortcodes widgets -----------------------------------------*/
add_filter('widget_text', 'do_shortcode');

?>
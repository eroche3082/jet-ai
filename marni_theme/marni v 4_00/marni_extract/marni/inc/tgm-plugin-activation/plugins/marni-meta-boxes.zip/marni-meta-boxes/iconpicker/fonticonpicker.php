<?php
/**
 * This class defines new "icon" field type for Meta Box class
 */
if ( class_exists( 'RWMB_Field' ) )
{
	class RWMB_Icon_Field extends RWMB_Field
	{
		
		/**
		 * Get field HTML
		 *
		 * @param mixed $meta
		 * @param array $field
		 *
		 * @return string
		 */
		static public function html( $meta, $field )
		{			
			return sprintf(
				'<input class="rwmb-text iconpicker" 
					name="%s" 
					id="%s" 
					value="%s" >',
				$field['field_name'],
				$field['id'],
				$meta
			);
		}

	}

	/* enqueue scripts and styles -----------------------------------------------*/
	function marni_rwmb_icon_field_enqueue() {
		wp_enqueue_style( 'marni-rwmb-iconpicker', plugin_dir_url( __FILE__ ) . 'jquery.fonticonpicker.min.css', false, 'screen');
		wp_enqueue_style( 'marni-rwmb-iconpicker-default', plugin_dir_url( __FILE__ ) . 'jquery.fonticonpicker.grey.min.css', false, 'screen');
		wp_enqueue_script( 'marni-rwmb-iconpicker', plugin_dir_url( __FILE__ ) . 'jquery.fonticonpicker.min.js', array('jquery'), '1.0' );
		wp_enqueue_script( 'marni-rwmb-iconpicker-scripts', plugin_dir_url( __FILE__ ) . 'jquery.fonticonpicker.scripts.js', array('jquery'), '1.0' );
	}
	add_action('admin_enqueue_scripts', 'marni_rwmb_icon_field_enqueue');



}

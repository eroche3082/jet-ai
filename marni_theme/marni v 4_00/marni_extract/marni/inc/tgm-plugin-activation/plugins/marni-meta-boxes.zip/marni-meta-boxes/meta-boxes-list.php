<?php

add_filter( 'rwmb_meta_boxes', 'marni_plugin_register_meta_boxes' );
function marni_plugin_register_meta_boxes( $meta_boxes ) {

$prefix = 'redsun_';


/** SINGLE POST fields **/
$meta_boxes[] = array(
        'title' =>  '<span class="dashicons dashicons-location"></span> ' .  esc_html__( 'Location','marni'), 
        'post_types' => 'post',
        'priority' => 'high',  
        'fields' => array(  
                array(
                        'name' => esc_html__('Location','marni'), 
                        'desc' => esc_html__('Add a location for this post.','marni'),             
                        'id' => $prefix . 'location',
                        'type' => 'text', 
                ),
        ),
);

$meta_boxes[] = array(
        'title' =>  '<span class="dashicons dashicons-align-left"></span> ' .esc_html__('Layout','marni'), 
        'post_types' => 'post',
        'priority' => 'high',  
        'fields' => array(  
                array(
                'name' => esc_html__('Featured Image','marni'), 
                'id' => $prefix . 'featured-image',      
                'type' => 'select', 
                'options' => array (
                        'standard' => esc_html__('Standard','marni'),
                        'fullwidth-overlay' => esc_html__('Widescreen + Overlay Title','marni'),
                        'floating-right' => esc_html__('Floating Right','marni'),
                        'floating-left' => esc_html__('Floating Left','marni'),
                        ), 
                'hidden' => array( 'post_format', 'video' ),
                'std' => 'standard',          
                ),                    
                array(
                        'name' => esc_html__('Layout','marni'),             
                        'id' => $prefix . 'single-layout',  
                        'desc' => esc_html__('(Content width for Fullwidth Page Narrow can be set in the Customizer.)','marni'),     
                        'type' => 'select', 
                        'options' => array (
                                'has-sidebar' => esc_html__('Right Sidebar','marni'),
                                'sidebar-below-title' => esc_html__('Right Sidebar below Title (use with Standard Image only)','marni'),
                                'sidebar-below-thumb' => esc_html__('Right Sidebar below Featured Image (use with Standard Image only)','marni'),
                                'fullwidth' => esc_html__('Fullwidth Page (No Sidebar)','marni'),
                                'fullwidth-narrow' => esc_html__('Fullwidth Page Narrow (No Sidebar)','marni'),
                                'fullscreen' => esc_html__('Fullscreen (No Sidebar, Width of entire Browser Window)','marni'),
                                ), 
                        'hidden' => array( 'post_format', 'video' ),
                        'std' => 'sidebar-below-thumb',          
                ),
                array(
                        'name' => esc_html__('Layout','marni'),             
                        'id' => $prefix . 'single-video-layout',      
                        'type' => 'select', 
                        'options' => array (
                                'fullwidth' => esc_html__('No Sidebar (Fullwidth Page)','marni'),
                                'has-sidebar' => esc_html__('Right Sidebar','marni'),
                                'sidebar-below-title' => esc_html__('Right Sidebar below Title','marni'),
                                'sidebar-below-thumb' => esc_html__('Right Sidebar below Video','marni'),
                                ), 
                        'visible' => array( 'post_format', 'video' ),
                        'std' => 'sidebar-below-thumb',          
                ),    
        ),
);

$meta_boxes[] = array(
        'title' =>  '<span class="dashicons dashicons-images-alt"></span> ' .  esc_html__( 'Home Slider','marni'), 
        'post_types' => 'post',
        'priority' => 'high',  
        'fields' => array(  
                array(
                        'name' => esc_html__('Feature Post in Home Slider','marni'), 
                        'id' => $prefix . 'sliderpost',
                        'type' => 'checkbox', 
                ),
                 array(
                        'name' => esc_html__('Order Number','marni'), 
                        'id' => $prefix . 'sliderpostorder',
                        'type' => 'number', 
                        'std' => '1',
                ),
        ),
);

$meta_boxes[] = array(
        'title' =>  '<span class="dashicons dashicons-schedule"></span> ' .  esc_html__( 'Gallery Post Type','marni'), 
        'post_types' => 'post',
        'visible' => ['post_format', 'gallery'],
        'priority' => 'high',  
        'fields' => array(  
                array(
                        'name' => esc_html__('Images','marni'), 
                        'id' => $prefix . 'gallery',
                        'type' => 'image_advanced', 
                ),
               array(
                'name' => esc_html__('Images per Row','marni'), 
                'id' => $prefix . 'gallery_rows',      
                'type' => 'select', 
                'options' => array (
                        '1' => esc_html__('One','marni'),
                        '2' => esc_html__('Two','marni'),
                        '3' => esc_html__('Three','marni'),
                        '4' => esc_html__('Four','marni'),
                        '5' => esc_html__('Five','marni'),
                        ), 
                'std' => '3',          
                ), 

        ),
);

$meta_boxes[] = array(
        'title' =>  '<span class="dashicons dashicons-video-alt3"></span> ' .  esc_html__( 'Video Post Type','marni'), 
        'post_types' => 'post',
        'visible' => array( 'post_format', 'video' ),
        'priority' => 'high',  
        'fields' => array(  
                array(
                        'name' => esc_html__('Video URL or embed code','marni'), 
                        'desc' => esc_html__('Add a YouTube or Vimeo URL or embed code.','marni'),             
                        'id' => $prefix . 'videourl',
                        'type' => 'textarea', 
                ), 
        ),
);


/** CATEGORY FIELDS ***************************************************************************************/

$meta_boxes[] = array(
	'title' =>  esc_html__('Category Image','marni'), 
	'taxonomies' => 'category', 
	'fields' => array(
		array(
			'name' => esc_html__( 'Upload a Category Image', 'marni' ),
			'id'   => $prefix . 'category-image',
			'type' => 'image_advanced',
			'max_file_uploads' => 1,
		),                
	),
);



/** PAGES FIELDS ***************************************************************************************/

$meta_boxes[] = array(
        'id' => 'pagebgimage',
        'title' =>  esc_html__('PAGE OPTIONS for template "Page with Background Image" ','marni'), 
        'pages' => array('page'), 
        'visible' => array('page_template', 'page-templates/page-bg-image.php'),
	'fields' => array(     
                array(
                        'name' => esc_html__('Content Max Width','marni'),  
                        'desc' => esc_html__('Enter the max width for the the content (in pixels).','marni'),                                  
                        'id' => $prefix . 'page-width',      
                        'type' => 'number',          
                        'std' => '720',      
                        'min' => '0',   
                ),
                 array(
                        'name' => esc_html__('Title Color','marni'),  
                        'id' => $prefix . 'page-title-color',      
                        'type' => 'color',          
                        'std' => '#101020',      
                ),
        ),
);










/** CONTENT BOXES ***************************************************************************************/

// BOX TYPE
$meta_boxes[] = array(
        'id' => 'boxtype',
        'title' =>  esc_html__('BOX TYPE','marni'), 
        'pages' => array('contentboxes'),
        'fields' => array( 
                array(
                        'id' => $prefix . 'contentbox-type',      
                        'type' => 'select_advanced',
                        'placeholder' => esc_html__( 'Select the box type...','marni'), 
                        'options' => array (
                        	'post-box' => esc_html__('Post Box','marni'),
                                'content-box' => esc_html__('Content Box','marni')
                                ),
                        'std' => 'content-box', 
                ), 
    	),
);

// BOX STYLE
$meta_boxes[] = array(
        'id' => 'contentboxes-style',
        'title' => esc_html__('BOX STYLE','marni'), 
        'pages' => array('contentboxes'),
        'post_types' => 'contentboxes',
        'fields' => array( 
                array(
                        'name' => esc_html__('Box Width','marni'),             
                        'id' => $prefix . 'contentbox-width',      
                        'type' => 'select_advanced',
                        'placeholder' => esc_html__( 'Select the box width...', 'marni' ),
                        'options' => array (
                                'one-fourth' => esc_html__('1/4','marni'),
                                'one-half' => esc_html__('1/2','marni'),
                                'one-third' => esc_html__('1/3','marni'),
                                'two-third' => esc_html__('2/3','marni'),
                                'full-width' => esc_html__('full width','marni')
                                ),   
                        'columns' => 6,       
                        'std' => 'two-third',     
			'admin_columns' => true,                
                ),
                array(
                        'name' => esc_html__('Box Height','marni'),             
                        'id' => $prefix . 'contentbox-height',      
                        'type' => 'select_advanced',
                        'tooltip' => array(
				'icon'     => 'info',
				'content'  => esc_html__( 'box height will expand if box content exceeds the selected height.', 'marni' ),
				'position' => 'right',
			),
                        'placeholder' => esc_html__( 'Select the box height...', 'marni' ),                        
                        'options' => array (
                                'undefined' => esc_html__('undefined','marni'),
                                'defined square' => esc_html__('100% (square)','marni'),
                                'defined half-height' => esc_html__('50% (landscape)','marni'),
                                'defined one-and-a-half-height' => esc_html__('150% (portrait)','marni'),
                                'defined double-height' => esc_html__('200% (portrait high)','marni')
                                ),   
                        'columns' => 6,       
                        'std' => 'defined square',    
			'admin_columns' => true,                     
                ),
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),  
		array(
                        'name' => esc_html__('Box Content Overlay Style','marni'),             
                	'id' => $prefix . 'contentbox-style',
                	'type' => 'radio', 
                	'options' => array(
			        'white' => 'White Text',
			        'dark' => 'Dark Text in White Box',
			    ),
                	'inline' => false,
                	'std' => 'white', 
                	'columns' => 6,
                ),    
		array(
                        'name' => esc_html__('Dark Overlay','marni'),             
                	'id' => $prefix . 'contentbox-darkoverlay',
                	'type' => 'switch', 
                	'hidden' => array( 'contentbox-style', '!=', 'white' ),
                	'desc' => esc_html__('Add dark overlay over image, in order to make white text more readable.','marni'), 
                	'columns' => 6,
                ),  
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),                  
                array(
                        'name' => esc_html__('Vertical Text on left side','marni'),             
                	'id' => $prefix . 'contentbox-verticaltext',
                	'type' => 'text', 
                	'columns' => 6,
                ),   
                array(
                        'name' => esc_html__('Vertical Text background color','marni'),             
                	'id' => $prefix . 'contentbox-verticaltextbgcolor',
                	'type' => 'color', 
                	'columns' => 6,
                ), 

	),
);

$meta_boxes[] = array(
        'id' => 'contentboxes-posts',
        'title' => esc_html__('FEATURED POST','marni'), 
        'pages' => array('contentboxes'),
        'post_types' => 'contentboxes',
        'hidden' => array( 'contentbox-type', 'in', array( 'content-box' ) ),
        'fields' => array( 
                array(
                        'name' => esc_html__('Select Post','marni'), 
                        'desc' => esc_html__('In order to search for a post, start typing the title...','marni'),            
                	'id' => $prefix . 'contentbox-post',
                	'type' => 'post', 
                	'placeholder' => esc_html__('Select a post...', 'marni' ),
                	'columns' => 12,
                ),
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),    
                array(
                        'name' => '<h4>' . esc_html__('DISPLAY POST INFO','marni') . '</h4>',             
                        'id' => $prefix . 'contentbox-admintitle',
                        'type' => 'custom_html',                              
                ),               
                array(
                        'name' => esc_html__('Category','marni'),             
                	'id' => $prefix . 'contentbox-category',
                	'type' => 'checkbox', 
                	'std' => 'on',
                	'columns' => 3,
                ),
               array(
                        'name' => esc_html__('More Button','marni'),             
                	'id' => $prefix . 'contentbox-morebutton',
                	'type' => 'checkbox', 
                	'std' => 'on',
                	'columns' => 3,
                ),
                array(
                        'name' => esc_html__('Date','marni'),             
                	'id' => $prefix . 'contentbox-date',
                	'type' => 'checkbox', 
                	'std' => 'on',
                	'columns' => 3,
                ),
                array(
                        'name' => esc_html__('Comments Number','marni'),             
                	'id' => $prefix . 'contentbox-commentsnumber',
                	'type' => 'checkbox', 
                	'columns' => 3,
                ),
                array(
                        'name' => esc_html__('Author','marni'),             
                	'id' => $prefix . 'contentbox-author',
                	'type' => 'checkbox', 
                	'columns' => 3,
                ),
                array(
                        'name' => esc_html__('Location','marni'),             
                	'id' => $prefix . 'contentbox-location',
                	'type' => 'checkbox', 
                	'columns' => 3,
                ),
                array(
                        'name' => esc_html__('Number of Views','marni'),             
                	'id' => $prefix . 'contentbox-views',
                	'type' => 'checkbox', 
                	'columns' => 3,
                ),
                array(
                	'id' => $prefix . 'contentbox-placeholder',
                	'type' => 'custom_html', 
                	'columns' => 3,
                ),
		                         
	),
);







// CONTENT BOX CONTENT
$meta_boxes[] = array(
        'id' => 'contentboxes-content',
        'title' => esc_html__('BOX CONTENT','marni'), 
        'pages' => array('contentboxes'),
        'visible' => array('contentbox-type', 'content-box'),
        'fields' => array( 

                array(
                        'name' => esc_html__('Background Image','marni'),             
                        'desc' => wp_kses(__('In order to display a background image,<br> upload a <strong>Featured Image</strong> on the right hand side.','marni'), array( 'strong' => array(), 'br' => array() ) ),                          
                	'id' => $prefix . 'contentbox-bgimage',
                	'type' => 'custom_html', 
                	'columns' => 6,
                ),  
                 array(
                        'name' => esc_html__('Box links to','marni'),              
                        'id' => $prefix . 'contentbox-url',
                        'type' => 'text',  
                        'desc' => esc_html__('Enter full URL including http://','marni'),                
                        'std' => '',     
                        'columns' => 6,               
                ), 
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),                   
                array(
                        'name' => esc_html__('Icon above Text','marni'),              
                        'id' => $prefix . 'contentbox-icon',
                        'type' => 'icon',  
                        'std' => '',     
                        'columns' => 6,
                ),
		array(
                        'name' => esc_html__('Icon Size','marni'),             
                	'id' => $prefix . 'contentbox-iconsize',
                	'type' => 'slider', 
                	'suffix' => ' em',
                	'js_options' => array(
			        'min'   => 2,
			        'max'   => 7,
			        'step'  => 0.1,
			),
			'std' => 3,
                	'columns' => 6,
                ),  

                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),                  
		array(
                        'name' => esc_html__('Text Font Family','marni'),             
                	'id' => $prefix . 'contentbox-font',
                	'type' => 'radio', 
                	'options' => array(
			        'base' => 'Use Base Font',
			        'heading' => 'Use Heading Font',
			    ),
			'tooltip' => array(
				'icon'     => 'info',
				'content'  => esc_html__( 'You can use the Base font or the Heading font as set in Appearance > Customize > Typography', 'marni' ),
				'position' => 'right',
			),
                	'inline' => false,
                	'std' => 'heading', 
                	'columns' => 4,
                ),    
		array(
                        'name' => esc_html__('Text Size','marni'),             
                	'id' => $prefix . 'contentbox-fontsize',
                	'type' => 'slider', 
                	'suffix' => ' em',
                	'js_options' => array(
			        'min'   => 1,
			        'max'   => 5,
			        'step'  => 0.1,
			),
			'std' => 1,
                	'columns' => 4,
                ),    
		array(
                        'name' => esc_html__('Letter Spacing','marni'),             
                	'id' => $prefix . 'contentbox-letterspacing',
                	'type' => 'slider', 
                	'suffix' => ' px',
                	'js_options' => array(
			        'min'   => 0,
			        'max'   => 10,
			        'step'  => 0.1,
			),
			'std' => 0,
                	'columns' => 4,
                ), 
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',          
                ),                  
                array(
                        'name' => esc_html__('Content','marni'),             
                        'id' => $prefix . 'contentbox-content',      
                        'type' => 'wysiwyg',
                        'desc' => wp_kses(__('Paragraphs will not be inserted automatically. In the text (not visual) editor, add &lt;br> for line breaks.<br>
                        			You can also use <a target="_blank" href="https://www.w3schools.com/html/html_styles.asp">HTML</a> and <a target="_blank" href="http://marni.redsun.design/shortcodes/">shortcodes</a>',
	  				'marni'),
	  				array( 
                        			'a' => array(
                        				'href' => array(),
                        				'target' => array(),
                        				),
                        			'br' => array(), 
                        		) 
                        	),  
                        'raw' => 'true', 
                        'options' => array (
                                'media_buttons' => 'false',
                                'editor_height' => '200',
                                'teeny' => 'false'
                                ), 
                        'columns' => 12,               
                        'std' => '',
                ),
                array(
                        'name' => esc_html__('Divider','marni'),             
                        'id' => $prefix . 'contentbox-divider',      
                        'type' => 'divider',
                ), 


    	),
);











return $meta_boxes;

} ?>
<?php
/*
Plugin Name: Marni Meta Boxes
Plugin URI: http://www.red-sun-design.com
Description: Meta Boxes for Marni WordPress Theme
Version: 2.1
Author: Gerda Gimpl
Author URI: http://www.red-sun-design.com
*/


add_action('plugins_loaded', 'marni_metaboxes_init');

function marni_metaboxes_init() {
	if ( class_exists('RWMB_Field') ) {

		include_once plugin_dir_path( __FILE__ ) . 'meta-boxes-list.php';	

		// icon picker 
		include_once plugin_dir_path( __FILE__ ) . 'iconpicker/fonticonpicker.php';

		// meta box columns
		include_once plugin_dir_path( __FILE__ ) . 'meta-box-columns/meta-box-columns.php';

		// meta box conditional logic
		include_once plugin_dir_path( __FILE__ ) . 'meta-box-conditional-logic/meta-box-conditional-logic.php';

		// meta box tooltip
		include_once plugin_dir_path( __FILE__ ) . 'meta-box-tooltip/meta-box-tooltip.php';

		// meta box term meta
		global $wp_version;
		if( version_compare( $wp_version, '4.4', '>=') ) {
			include_once plugin_dir_path( __FILE__ ) . 'mb-term-meta/mb-term-meta.php';
		}

	} 
} ?>
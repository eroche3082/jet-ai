<?php
/*
Plugin Name: Marni Shortcodes
Plugin URI: http://www.red-sun-design.com
Description: Shortcodes for Marni WordPress Theme
Version: 1.01
Author: Gerda Gimpl
Author URI: http://www.red-sun-design.com
*/



/* enqueue scripts and styles -----------------------------------------------*/
function marni_shortcodes_scripts() {
        if (!is_admin()) {
		wp_enqueue_style( 'marni-shortcodes', plugins_url( '/css/shortcodes.css', __FILE__ ), false, 'screen');
        	// RTL
		wp_style_add_data( 'marni-shortcodes', 'rtl', 'replace' );
        }
}
add_action('init', 'marni_shortcodes_scripts');




/* COLUMNS -------------------------------------------------------------------*/
function spoon_one_half( $atts, $content = null ) {
        return '<div class="one_half">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'spoon_one_half');

function spoon_one_half_last( $atts, $content = null ) {
        return '<div class="one_half last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('one_half_last', 'spoon_one_half_last');

function spoon_one_third( $atts, $content = null ) {
        return '<div class="one_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_third', 'spoon_one_third');

function spoon_one_third_last( $atts, $content = null ) {
        return '<div class="one_third last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('one_third_last', 'spoon_one_third_last');

function spoon_two_third( $atts, $content = null ) {
        return '<div class="two_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_third', 'spoon_two_third');

function spoon_two_third_last( $atts, $content = null ) {
        return '<div class="two_third last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('two_third_last', 'spoon_two_third_last');

function spoon_one_fourth( $atts, $content = null ) {
        return '<div class="one_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fourth', 'spoon_one_fourth');

function spoon_one_fourth_last( $atts, $content = null ) {
        return '<div class="one_fourth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('one_fourth_last', 'spoon_one_fourth_last');

function spoon_three_fourth( $atts, $content = null ) {
        return '<div class="three_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fourth', 'spoon_three_fourth');

function spoon_three_fourth_last( $atts, $content = null ) {
        return '<div class="three_fourth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('three_fourth_last', 'spoon_three_fourth_last');

function spoon_one_fifth( $atts, $content = null ) {
        return '<div class="one_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fifth', 'spoon_one_fifth');

function spoon_one_fifth_last( $atts, $content = null ) {
        return '<div class="one_fifth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('one_fifth_last', 'spoon_one_fifth_last');        

function spoon_two_fifth( $atts, $content = null ) {
        return '<div class="two_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_fifth', 'spoon_two_fifth');

function spoon_two_fifth_last( $atts, $content = null ) {
        return '<div class="two_fifth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('two_fifth_last', 'spoon_two_fifth_last');        

function spoon_three_fifth( $atts, $content = null ) {
        return '<div class="three_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fifth', 'spoon_three_fifth');

function spoon_three_fifth_last( $atts, $content = null ) {
        return '<div class="three_fifth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('three_fifth_last', 'spoon_three_fifth_last');        

function spoon_four_fifth( $atts, $content = null ) {
        return '<div class="four_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('four_fifth', 'spoon_four_fifth');

function spoon_four_fifth_last( $atts, $content = null ) {
        return '<div class="four_fifth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('four_fifth_last', 'spoon_four_fifth_last');        

function spoon_one_sixth( $atts, $content = null ) {
        return '<div class="one_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_sixth', 'spoon_one_sixth');

function spoon_one_sixth_last( $atts, $content = null ) {
        return '<div class="one_sixth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('one_sixth_last', 'spoon_one_sixth_last');        

function spoon_five_sixth( $atts, $content = null ) {
        return '<div class="five_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('five_sixth', 'spoon_five_sixth');

function spoon_five_sixth_last( $atts, $content = null ) {
        return '<div class="five_sixth last">' . do_shortcode($content) . '</div>
        <div class="clearboth"></div>';
}
add_shortcode('five_sixth_last', 'spoon_five_sixth_last');        




/* DROPCAPS ------------------------------------------------------------------*/
function marni_dropcap($atts, $content= null, $code="") {
        $return = '<span class="dropcap">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap' , 'marni_dropcap' );

function marni_dropcap_large($atts, $content= null, $code="") {
        $return = '<span class="dropcap dropcap_large">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap_large' , 'marni_dropcap_large' );




function marni_dropcap_line($atts, $content= null, $code="") {
        $return = '<span class="dropcap_line">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap_line' , 'marni_dropcap_line' );

function marni_dropcap2_line($atts, $content= null, $code="") {
        $return = '<span class="dropcap2_line">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap2_line' , 'marni_dropcap2_line' );




function marni_dropcap2($atts, $content= null, $code="") {
        $return = '<span class="dropcap2">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap2' , 'marni_dropcap2' );


function marni_dropcap2_large($atts, $content= null, $code="") {
        $return = '<span class="dropcap2_large">'.$content.'</span>';
        return $return;
}
add_shortcode('dropcap2_large' , 'marni_dropcap2_large' );



/* PULLQUOTE -----------------------------------------------------------------*/
function spoon_pullquote_left($atts, $content=null, $code="") {
        $return = '<span class="pullquote_left"><span class="pullquote_wrap">'.$content.'</span></span>';
        return $return;
}
add_shortcode('pullquote_left' , 'spoon_pullquote_left' );

function spoon_pullquote_right($atts, $content=null, $code="") {
        $return = '<span class="pullquote_right"><span class="pullquote_wrap">'.$content.'</span></span>';
        return $return;
}
add_shortcode('pullquote_right' , 'spoon_pullquote_right' );




/* HIGHLIGHT -----------------------------------------------------------------*/
function marni_highlight($atts, $content=null, $code="") {
	extract(shortcode_atts(array(
        	'color' => '',
       	), $atts));
	
        $return = '<span class="highlight" style="background-color:'.$color.'">' . $content . '</span>';
        return $return;
}
add_shortcode('highlight' , 'marni_highlight' );


function marni_highlight2($atts, $content=null, $code="") {
	extract(shortcode_atts(array(
        	'color' => '',
       	), $atts));
	
        $return = '<span class="highlight2" style="background-color:'.$color.'">' . $content . '</span>';
        return $return;
}
add_shortcode('highlight2' , 'marni_highlight2' );




/* DIVIDER -----------------------------------------------------------------*/
function spoon_divider_hr( $atts, $content = null ) {
        return '<div class="divider_hr"></div>';
}
add_shortcode('divider', 'spoon_divider_hr');

function spoon_divider2_hr( $atts, $content = null ) {
        return '<div class="divider2_hr"></div>';
}
add_shortcode('divider2', 'spoon_divider2_hr');





/* BUTTONS ------------------------------------------------------------------*/
function spoon_button($atts, $content = null) {
             
        extract(shortcode_atts(array(
                'link' => '#',
                'window' => '',
                'size' => '',
                'color' => '',
                'style' => '',
        ), $atts));

        $target = ($window == 'new') ? ' target="_blank"' : '';
        $buttonstyle = ($style == 'outline') ? ' button-outline' : ' button-regular';
        $size = ($size == 'large') ? ' button-large' : '';
        //$color = ($color) ?  $color :  '#101214';
	$hascolor = ($color != '') ? ' has-color' : '';

	$regularbuttoncolor = '#ffffff';

        $stylecss = ($style == 'outline' && $color != '') ? 
        	' style="color: ' . $color . '; border: 1px solid ' . $color . '"'  :
        	 ( $color ? 
        	 	' style="background-color: ' . $color . '; border: 1px solid ' . $color. '"' : ''
        	 ); 

	$datacolor = ($color != '') ? 'data-color="' . $color . '"' : '';


        	
        $out =  '<a' .$target. ' class="button shortcode-button' . $buttonstyle . $size . $hascolor . ' " ' . $stylecss . $datacolor . '  href="' . $link . '" ><span>' . do_shortcode($content) . '</span></a>';

        return $out;

}
add_shortcode('button', 'spoon_button');







?>